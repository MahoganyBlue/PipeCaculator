package com.galvins.pipecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    EditText input;
    TextView metersView;
    TextView lengthsView;
    Button enter;
    int question = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input = findViewById(R.id.textEditConversion);
        metersView = findViewById(R.id.textViewMeters);
        lengthsView = findViewById(R.id.textViewLengths);
        enter = findViewById(R.id.button);

        /*on button click retrieve int input from editText(input) and put into integer(question)
        * then set lengthsView with lengthMath method and set metersView with metersMath method.
        * catch any exceptions and do nothing.*/
        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                   question = Integer.parseInt(input.getText().toString());
                   setLengthsView("Lengths:" + lengthMath(question));
                   setMetersView("Meters:" + metersMath(question));
                } catch (Exception x) { }
            }
        });
    }

    /*lengthMath method is set to receive the input from the user and return the total amount of
    * lengths of pipe within the users original meters */
    public int lengthMath(int input){
        return input / 6;
    }
    /*metersMath method receives the users input meters and uses the lengthMath method to find the
    * number of whole lengths then multiply that by six to get the number of meters in those lengths,
    * then finally take that from the initial figure to get the meters remaining.
    * Example: 32/6=5 | 5*6=30 | 32-30=2 */
    public int metersMath(int input){
        return input - (lengthMath(input)*6);
    }

    //set text for meters
    public void setMetersView(String x){
        metersView.setText(x);
    }
    //set text for lengths
    public void setLengthsView(String x){
        lengthsView.setText(x);
    }



}
